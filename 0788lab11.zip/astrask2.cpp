#include <iostream>
using namespace std;

int main(void) {
	int arr[5] = { 0x12345678, 0x9ABCDEF0, 0x13579BDF, 0x2468ACE0, 0xFEDCBA98 };

	for (int i = 0; i < 5; ++i) {
	
		_asm {
			mov eax, arr[i]
				rol al, 8           
				ror ah, 8           
				mov arr[i], eax
		}

		
		_asm {
			mov eax, arr[i]
				ror al, 8          
				rol ah, 8           
				mov arr[i], eax
		}

		
		_asm {
			mov eax, arr[i]
				ror ax, 8          
				rol ax, 8           
				mov arr[i], eax
		}
	}


	for (int i = 0; i < 5; ++i) {
		cout << "arr[" << i << "] = " << hex << arr[i] << dec << endl;
	}

	return 0;
}
