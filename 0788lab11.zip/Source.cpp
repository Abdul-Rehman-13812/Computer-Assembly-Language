#include <iostream>
using namespace std;
int main() {
	int arr[5] = { 1,2,3,4,5 };

	for (int i = 0; i < 5; ++i) {
	
		_asm {
			mov eax, arr[i]
				bswap eax
				mov arr[i], eax
		}

	
		_asm {
			mov ebx, arr[i]
				shr ebx, 8         
				and ebx, 0x00FF    
				ror ebx, 4         
				shl ebx, 8          
				or arr[i], ebx    
		}
	}

	
	for (int i = 0; i < 5; ++i) {
		cout << "arr[" << i << "] = " << hex << arr[i] << dec << endl;
	}

	return 0;
}
